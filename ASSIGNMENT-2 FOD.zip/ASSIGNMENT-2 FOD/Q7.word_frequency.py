'''
word_frequency.py

This program defines a function that takes a sentence as input and returns a
dictionary containing the frequency of each word in the sentence.
'''

def word_frequency(sentence):
    '''
    Function to count the frequency of each word in a sentence
    '''
    words = sentence.split()
    frequency = {}
    for word in words:
        if word in frequency:
            frequency[word] += 1
        else:
            frequency[word] = 1
    return frequency

# Test the function with a sentence
sentence = "A fox jumps over the lazy rabbit with a nasty breath."
frequency = word_frequency(sentence)
print("Word:", frequency)
