'''
card_guessing_game.py

This program generates a card guessing game. The user has to guess the card value and
suit chosen randomly by the program.
'''

import random

def card_guessing_game():
    '''
    Function to play a card guessing game
    '''
    card_values = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King",
                   "Ace"]
    card_suits = ["Hearts", "Diamonds", "Clubs", "Spades"]

    chosen_value = random.choice(card_values)
    chosen_suit = random.choice(card_suits)

    print("Guess the card!")
    user_value = input("Enter card value (2-10, Jack, Queen, King, Ace): ")
    user_suit = input("Enter card suit (Hearts, Diamonds, Clubs, Spades): ")

    if user_value == chosen_value and user_suit == chosen_suit:
        print("Congratulations! You guessed it right!")
    elif user_value == chosen_value or user_suit == chosen_suit:
        print("Almost there! ")
    else:
        print("Wrong guess! Game over.")

# Play the game
card_guessing_game()
