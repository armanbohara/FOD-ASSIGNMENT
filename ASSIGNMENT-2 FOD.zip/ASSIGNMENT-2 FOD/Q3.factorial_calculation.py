'''
factorial_calculation.py

This program defines a function that accepts a number and returns its factorial.
The output is displayed in a proper format.
'''

def factorial(n):
    '''
    Function to calculate the factorial of a number
    '''
    if n == 0:
        return 1
    else:
        return n * factorial(n - 1)

# Input from the user
num = int(input("Enter a number: "))

# Calculate and display factorial
print(f"The factorial of {num} is {factorial(num)}")
