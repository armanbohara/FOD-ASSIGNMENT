'''
segregate_even_odd.py

This program continuously accepts numbers from the user and segregates them into even and
odd lists. Once the user chooses to exit,
it displays the separate lists of even and odd numbers.
'''

def segregate_even_odd():
    '''
    Function to segregate input numbers into even and odd lists
    '''
    even_numbers = []
    odd_numbers = []

    while True:
        user_input = input("Enter a number (or type 'exit' to finish): ")
        if user_input.lower() == 'exit':
            break
        try:
            num = int(user_input)
            if num % 2 == 0:
                even_numbers.append(num)
            else:
                odd_numbers.append(num)
        except ValueError:
            print("Please enter a valid number.")

    print("Even numbers:", even_numbers)
    print("Odd numbers:", odd_numbers)

# Call the function
segregate_even_odd()
