'''
book_details.py

This program asks the user for the details of 5 books (title, author, ISBN, cost),
adds them to a dictionary,
and prints the details.
'''

def add_books():
    '''
    Function to add details of 5 books to a dictionary and print them
    '''
    books = {}
    for i in range(1, 6):
        title = input(f"Enter title of book {i}: ")
        author = input(f"Enter author of book {i}: ")
        isbn = input(f"Enter ISBN of book {i}: ")
        cost = float(input(f"Enter cost of book {i}: "))
        books[i] = {"Title": title, "Author": author, "ISBN": isbn, "Cost": cost}
    return books

# Add books and display details
book_details = add_books()
print("Details of the books:")
for index, details in book_details.items():
    print(f"Book {index}: {details}")
