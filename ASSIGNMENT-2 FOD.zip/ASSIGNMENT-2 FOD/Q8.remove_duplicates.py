'''
remove_duplicates.py

This program accepts a list of numbers from the user and returns a list with
duplicate values removed.
'''

def remove_duplicates(numbers):
    '''
    Function to remove duplicate values from a list
    '''
    return list(set(numbers))

# Input list of numbers from the user
numbers_list = list(map(int, input("Enter a list of numbers separated by space: ").split()))

# Remove duplicates and display result
unique_numbers = remove_duplicates(numbers_list)
print("List after removing duplicates:", unique_numbers)
