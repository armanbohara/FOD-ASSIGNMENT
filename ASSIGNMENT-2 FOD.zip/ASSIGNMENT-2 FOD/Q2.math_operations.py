'''
math_operations.py

This program defines separate functions for various mathematical calculations:
addition, subtraction,
multiplication, division, modulo division, and floor division.
It takes two inputs from the user and
displays the results.
'''

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    return a / b

def modulo_divide(a, b):
    return a % b

def floor_divide(a, b):
    return a // b

# Input from the user
num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))

# Display results
print(f"Addition: {add(num1, num2)}")
print(f"Subtraction: {subtract(num1, num2)}")
print(f"Multiplication: {multiply(num1, num2)}")
print(f"Division: {divide(num1, num2)}")
print(f"Modulo Division: {modulo_divide(num1, num2)}")
print(f"Floor Division: {floor_divide(num1, num2)}")
