'''
search_city.py

This program defines a function that accepts a list of cities and a city to search for. It returns the index
of the city if found, or a proper message if not found.
'''

def search_city(cities, city):
    '''
    Function to search for a city in a list of cities
    '''
    if city in cities:
        return cities.index(city)
    else:
        return "City not found"

# Test the function with a list of cities
cities_list = ["Monte Carlo", "Paris", "St Tropez", "LA", "Alps"]
city_to_search = "LA"
index = search_city(cities_list, city_to_search)
print(f"Index of {city_to_search}: {index}")
