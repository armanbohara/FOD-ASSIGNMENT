'''
number_occurrences.py

This program defines a function that accepts a list of numbers and prints the
occurrence of each number.
'''

def count_occurrences(numbers):
    '''
    Function to count the occurrences of each number in a list
    '''
    occurrences = {}
    for num in numbers:
        if num in occurrences:
            occurrences[num] += 1
        else:
            occurrences[num] = 1
    return occurrences

# Test the function with various lists
numbers_list = [1, 2,2,2,2, 2, 3, 3, 3,3,3, 4, 4, 4,4,4,4, 4]
occurrences = count_occurrences(numbers_list)
print("Occurrences of each number:", occurrences)
