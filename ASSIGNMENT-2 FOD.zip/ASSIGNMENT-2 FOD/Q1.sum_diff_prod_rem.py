'''
sum_diff_prod_rem.py

This program defines a function that accepts two numbers and displays their sum, difference,
product, and remainder.
'''

def arith_operations(a, b):
    '''
    Function to calculate and display the sum, difference, product, and remainder of two
    numbers
    '''
    sum = a + b
    diff = a - b
    prod = a * b
    rem = a % b
    
    print(f"Sum of {a} and {b} is: {sum}")
    print(f"Difference of {a} and {b} is: {diff}")
    print(f"Product of {a} and {b} is: {prod}")
    print(f"Remainder of {a} and {b} is: {rem}")

# Input from the user
num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))

# Call the function
arith_operations(num1, num2)
