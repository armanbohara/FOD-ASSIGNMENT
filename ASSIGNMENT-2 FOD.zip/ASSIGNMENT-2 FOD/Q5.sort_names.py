'''
sort_names.py

This program defines a function that accepts a list of names and returns them in sorted order.

'''

def sort_names(names):
    '''
    Function to sort a list of names
    '''
    return sorted(names)

# Test the function with a list of names
names_list = ["Jack", "David", "Leo", "Mark"]
sorted_names = sort_names(names_list)
print("Sorted names:", sorted_names)
