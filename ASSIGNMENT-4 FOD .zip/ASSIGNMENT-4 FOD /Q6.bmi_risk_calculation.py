'''
bmi_risk_calculation.py

This program reads a csv file "weight_height.csv" using pandas, adds BMI and Risk columns based on
certain conditions, and updates the dataframe.
'''

import pandas as pd

# Read the csv file
df = pd.read_csv('weight_height.csv')

# Calculate BMI
df['BMI'] = df['weight'] / (df['height'] ** 2)

# Calculate Risk based on BMI
def calculate_risk(bmi):
    if bmi < 18.5:
        return "Nutrient deficient"
    elif 18.5 <= bmi < 24.9:
        return "Lower risk"
    elif 25 <= bmi < 29.9:
        return "Heart disease risk"
    elif 30 <= bmi < 34.9:
        return "Higher risk of diabetes, heart disease"
    else:
        return "Serious health condition risk"

df['Risk'] = df['BMI'].apply(calculate_risk)

# Display the updated dataframe
print(df)
