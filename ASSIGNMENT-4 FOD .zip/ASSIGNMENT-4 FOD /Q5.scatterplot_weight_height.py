'''
scatterplot_weight_height.py

This program reads a csv file "weight_height.csv" using pandas and plots scatterplots using matplotlib.
'''

import pandas as pd
import matplotlib.pyplot as plt

# Read the csv file
df = pd.read_csv('weight_height.csv')

# Scatterplot for weight vs height
plt.figure(figsize=(10,6 ))
plt.scatter(df['weight'], df['height'])
plt.xlabel('weight')
plt.ylabel('height')
plt.title('weight vs height')
plt.show()

# Scatterplot for age vs weight
plt.figure(figsize=(10, 6))
plt.scatter(df['age'], df['weight'])
plt.xlabel('age')
plt.ylabel('weight')
plt.title('age vs weight')
plt.show()

# Scatterplot for height vs age
plt.figure(figsize=(10, 6))
plt.scatter(df['height'], df['age'])
plt.xlabel('height')
plt.ylabel('age')
plt.title('height vs age')
plt.show()

# Scatterplot for gender vs height
plt.figure(figsize=(10, 6))
plt.scatter(df['gender'], df['height'])
plt.xlabel('gender')
plt.ylabel('height')
plt.title('gender vs height')
plt.show()

# Scatterplot for gender vs weight
plt.figure(figsize=(10, 6))
plt.scatter(df['gender'], df['weight'])
plt.xlabel('gender')
plt.ylabel('weight')
plt.title('gender vs weight')
plt.show()
