'''
numpy_array_operations.py

This program generates a numpy array of numbers and performs operations such as sum,average, 
maximum, and minimum values.
'''

import numpy as np

# Generate a numpy array
arr = np.array([123, 0, 12, 2])

# Sum of elements
sum_elements = np.sum(arr)
print(f"Sum of elements: {sum_elements}")

# Average of elements
average_elements = np.mean(arr)
print(f"Average of elements: {average_elements}")

# Maximum and Minimum values
max_value = np.max(arr)
min_value = np.min(arr)
print(f"Maximum value: {max_value}")
print(f"Minimum value: {min_value}")
