'''
matrix_operations.py

This program inputs 2 matrices and performs addition, subtraction, and multiplication using numpy.
'''

import numpy as np

# Input dimensions of the matrices
rows = int(input("Enter the number of rows: "))
cols = int(input("Enter the number of columns: "))

# Input first matrix
print("Enter elements of the first matrix:")
matrix1 = np.array([input().split() for _ in range(rows)], dtype=int)

# Input second matrix
print("Enter elements of the second matrix:")
matrix2 = np.array([input().split() for _ in range(rows)], dtype=int)

# Perform matrix operations if dimensions match
if matrix1.shape == matrix2.shape:
    sum_matrix = np.add(matrix1, matrix2)
    diff_matrix = np.subtract(matrix1, matrix2)
    prod_matrix = np.dot(matrix1, matrix2)
    
    print(f"Sum of matrices:\n{sum_matrix}")
    print(f"Difference of matrices:\n{diff_matrix}")
    print(f"Product of matrices:\n{prod_matrix}")
else:
    print("Matrix dimensions do not match. Cannot perform operations.")
