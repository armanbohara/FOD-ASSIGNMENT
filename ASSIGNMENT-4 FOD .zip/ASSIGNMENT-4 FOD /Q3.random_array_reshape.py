'''
random_array_reshape.py

This program creates an array of random integer numbers, sorts them, and reshapes them into a matrix.
'''

import numpy as np

# Generate a random integer array of size 10
random_arr = np.random.randint(1, 100, size=10)
print(f"Random array: {random_arr}")

# Sort the array
sorted_arr = np.sort(random_arr)
print(f"Sorted array: {sorted_arr}")

# Reshape the array into 2x5 matrix
reshaped_arr = sorted_arr.reshape(2, 5)
print(f"Reshaped array (2x5 matrix):\n{reshaped_arr}")
